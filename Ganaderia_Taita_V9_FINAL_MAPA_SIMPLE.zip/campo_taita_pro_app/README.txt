GANADERÍA TAITA - V7 PRO INSTALABLE

Cambios incluidos:
- Ícono profesional tipo Brangus colorado para iPhone/Android.
- App preparada como PWA instalable: queda en pantalla de inicio con ícono propio.
- Firebase integrado directamente con el proyecto ganaderiataita.
- Sincronización mejorada: usa Firestore en tiempo real y mantiene opción de URL Realtime Database si se pega una URL.
- Auto-sync: sincroniza cambios y hace respaldo cada 30 segundos.
- Interfaz más profesional, con menos emojis infantiles.
- Mapa satelital, dibujo/borrado de lotes, tropas, movimientos, mortandad, reportes CSV, días de ocupación y descanso.

IMPORTANTE PARA FIREBASE:
Para que la sincronización funcione, en Firebase debe estar habilitado Cloud Firestore para el proyecto ganaderiataita y las reglas deben permitir lectura/escritura a los usuarios que usarán la app.

INSTALACIÓN EN CELULAR:
1) Publicar esta carpeta/ZIP en Netlify u otro hosting.
2) Abrir el link desde Safari en iPhone o Chrome en Android.
3) iPhone: Compartir > Agregar a pantalla de inicio.
4) Android: Menú > Instalar app o Agregar a pantalla principal.

Archivo principal: index.html
